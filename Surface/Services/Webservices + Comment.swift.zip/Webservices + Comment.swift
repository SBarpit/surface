//
//  Webservices + Comment.swift
//  Surface
//
//  Created by Appinventiv Mac on 06/04/18.
//  Copyright © 2018 Appinventiv. All rights reserved.
//

import Foundation

extension WebServices {
    
    
     static func comment_add(params : JSONDictionary , success : @escaping success , failure: @escaping failure){
        
        
        AppNetworking.POST(endPoint: EndPoint.comment_add.url, success: { (result) in
            if result["code"].intValue == 200 {
                success(result)
            }else{
                handleError(message: result["msg"].stringValue, errorCode: result["code"].intValue, failure: failure)
            }

        }, { (error) in
            failure(error.localizedDescription,nil)
        })
        
}
    
    static func comment_reply(params: JSONDictionary, success : @escaping success , failure : @escaping failure){
        
        AppNetworking.POST(endPoint: EndPoint.comment_reply.url, success: { (result) in
            if result["code"].intValue == 200 {
                success(result)
            }else{
                handleError(message: result["msg"].stringValue, errorCode: result["code"].intValue, failure: failure)
            }
        },{ (error) in
            failure(error.localizedDescription,nil)

        })
        
    }
    
    static func reply_list(params: JSONDictionary, success : @escaping success , failure : @escaping failure){
        
        AppNetworking.GET(endPoint: EndPoint.get_notification_list.url, parameters: params, headers: access_token, loader:true,  success: { (result) in
            
            if result["code"].intValue == 200{
                success(result)
                
            } else{
                handleError(message: result["msg"].stringValue, errorCode: result["code"].intValue, failure: failure)
            }
            
        }, { (error) in
            failure(error.localizedDescription, nil)
        })
    }
      
    
    
    static func comment_list(params: JSONDictionary, success : @escaping success , failure : @escaping failure){
        
        AppNetworking.GET(endPoint: EndPoint.get_notification_list.url, parameters: params, headers: access_token, loader:true,  success: { (result) in
            
            if result["code"].intValue == 200{
                success(result)
                
            } else{
                handleError(message: result["msg"].stringValue, errorCode: result["code"].intValue, failure: failure)
            }
            
        }) { (error) in
            failure(error.localizedDescription, nil)
        }
}
}
